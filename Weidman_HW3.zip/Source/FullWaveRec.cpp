/*
  ==============================================================================

    FullWaveRec.cpp
    Created: 9 Apr 2024 9:42:13am
    Author:  Alek Weidman

  ==============================================================================
*/

#include "FullWaveRec.h"

float FullWaveRec::processSample(float x, const int c) {
    return abs(x);
}
